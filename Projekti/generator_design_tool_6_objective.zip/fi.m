function f = fi(xi)
f = xi*(sinh(2*xi)+sin(2*xi))/(cosh(2*xi)-cos(2*xi));