function p = psi(xi)
p = 2*xi*(sinh(xi) - sin(xi))/(cosh(xi) + cos(xi));